<br/>
<div class="alert alert-warning">
    <?php echo lang('account_pending_approval'); ?>
</div>