<p><?php echo $data['salute']; ?></p>

<p>
    <?php echo $data['message']; ?>
</p>