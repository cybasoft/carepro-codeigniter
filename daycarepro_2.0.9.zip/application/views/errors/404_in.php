<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
		<div class="error-page">
			<h2 class="headline text-info"> 404</h2>

			<div class="error-content">
				<h3><i class="fa fa-warning text-yellow"></i> <?php echo lang('404_subtitle'); ?>.</h3>

				<p>
					<?php echo lang('404_message'); ?>
				</p>
			</div>
		</div>
	</div>
</div>