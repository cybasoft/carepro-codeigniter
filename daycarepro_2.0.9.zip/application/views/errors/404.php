<div id="landing">
	<div class="container">
		<div class="row">
			<div class="span12">
				<div class="error-page">
					<h2 class="headline text-info"> 404</h2>

					<div class="error-content">
						<h3><i class="fa fa-warning text-yellow"></i><?php echo lang('404_subtitle'); ?></h3>
						<p>
							<?php echo lang('404_message'); ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>